// API configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000';

export interface SignupLocation {
  siteName: string;
  serviceType: string;
  addressLine1: string;
  addressLine2?: string | null;
  city: string;
  state: string;
  zipCode: string;
  notes?: string | null;
  desiredStartDate?: string | null;
}

export interface SignupPayload {
  company: {
    companyName: string;
    website?: string | null;
    companyType?: string | null;
    phone?: string | null;
    email?: string | null;
    estimatedStartDate?: string | null;
  };
  contact: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    jobTitle?: string | null;
  };
  locations: SignupLocation[];
  marketingOptIn: boolean;
  message?: string | null;
}

export interface SignupResponse {
  success: boolean;
  dealId: string;
  jobIds: string[];
  message: string;
}

export async function submitSignup(payload: SignupPayload): Promise<SignupResponse> {
  const response = await fetch(`${API_BASE_URL}/api/public/signup`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to submit signup' }));
    throw new Error(error.message || 'Failed to submit signup');
  }

  return response.json();
}

export interface ContractDetails {
  signatureRequest: {
    id: string;
    contractTitle: string;
    signerName: string;
    signerEmail: string;
    status: string;
    signPageUrl: string | null;
  };
  company: {
    name: string;
  };
  deal: {
    name: string;
  };
}

export async function getContractByToken(token: string): Promise<ContractDetails> {
  const response = await fetch(`${API_BASE_URL}/api/public/contract/${token}`);

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Failed to fetch contract' }));
    throw new Error(error.message || 'Failed to fetch contract');
  }

  return response.json();
}
