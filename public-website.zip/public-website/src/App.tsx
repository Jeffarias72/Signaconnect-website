import { Route, Switch } from 'wouter';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import WifiInstallationPage from './pages/WifiInstallationPage';
import CarrierEnhancementPage from './pages/CarrierEnhancementPage';
import EvChargingPage from './pages/EvChargingPage';
import DataCollectionPage from './pages/DataCollectionPage';
import SignupPage from './pages/SignupPage';
import ContractPortalPage from './pages/ContractPortalPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import NotFoundPage from './pages/NotFoundPage';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/services" component={ServicesPage} />
          <Route path="/services/wifi-installation" component={WifiInstallationPage} />
          <Route path="/services/carrier-enhancement" component={CarrierEnhancementPage} />
          <Route path="/services/ev-charging" component={EvChargingPage} />
          <Route path="/services/data-collection" component={DataCollectionPage} />
          <Route path="/signup" component={SignupPage} />
          <Route path="/contract/:token" component={ContractPortalPage} />
          <Route path="/privacy-policy" component={PrivacyPolicyPage} />
          <Route path="/terms-of-service" component={TermsOfServicePage} />
          <Route component={NotFoundPage} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
