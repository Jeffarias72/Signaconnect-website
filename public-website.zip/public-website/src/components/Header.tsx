import { Link } from 'wouter';
import { Phone, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <nav className="container-custom">
        <div className="flex justify-between items-center h-16">
          {/* Brand Text */}
          <Link href="/">
            <a className="text-xl font-bold text-primary-600 hover:text-primary-700 transition">
              SignaConnect
            </a>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="/">
              <a className="text-gray-700 hover:text-primary-600 transition">Home</a>
            </Link>
            <Link href="/services">
              <a className="text-gray-700 hover:text-primary-600 transition">Services</a>
            </Link>
            <a href="tel:9085324503" className="flex items-center gap-2 text-gray-700 hover:text-primary-600 transition">
              <Phone size={18} />
              (908) 532-4503
            </a>
            <Link href="/signup">
              <a className="btn btn-primary">Get Started</a>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col gap-4">
              <Link href="/">
                <a className="text-gray-700 hover:text-primary-600 transition" onClick={() => setMobileMenuOpen(false)}>
                  Home
                </a>
              </Link>
              <Link href="/services">
                <a className="text-gray-700 hover:text-primary-600 transition" onClick={() => setMobileMenuOpen(false)}>
                  Services
                </a>
              </Link>
              <a href="tel:9085324503" className="flex items-center gap-2 text-gray-700 hover:text-primary-600 transition">
                <Phone size={18} />
                (908) 532-4503
              </a>
              <Link href="/signup">
                <a className="btn btn-primary w-full" onClick={() => setMobileMenuOpen(false)}>
                  Get Started
                </a>
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
