import { Link } from 'wouter';
import { Mail, Phone } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-white text-xl font-bold mb-4">SignaConnect</h3>
            <p className="text-sm mb-4">
              Professional Wi-Fi network installation and carrier enhancement services.
              Powerful Wi-Fi. Proven Profit.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2">
              <Link href="/">
                <a className="hover:text-primary-400 transition">Home</a>
              </Link>
              <Link href="/services">
                <a className="hover:text-primary-400 transition">Services</a>
              </Link>
              <Link href="/signup">
                <a className="hover:text-primary-400 transition">Get Started</a>
              </Link>
            </div>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <div className="flex flex-col gap-2">
              <Link href="/privacy-policy">
                <a className="hover:text-primary-400 transition">Privacy Policy</a>
              </Link>
              <Link href="/terms-of-service">
                <a className="hover:text-primary-400 transition">Terms of Service</a>
              </Link>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <div className="flex flex-col gap-3">
              <a href="tel:9085324503" className="flex items-center gap-2 hover:text-primary-400 transition">
                <Phone size={18} />
                (908) 532-4503
              </a>
              <a href="mailto:info@signaconnect.com" className="flex items-center gap-2 hover:text-primary-400 transition">
                <Mail size={18} />
                info@signaconnect.com
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm">
          <p>&copy; {currentYear} SignaConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
