import { Link } from 'wouter';
import { Zap, CheckCircle, Clock, FileCheck, Shield, TrendingUp } from 'lucide-react';
import { useEffect } from 'react';

export default function EvChargingPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-20">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-6 flex justify-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-16 md:h-20 w-auto drop-shadow-lg"
              />
            </div>
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-2xl mb-6">
              <Zap size={40} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">EV Charging Installation</h1>
            <p className="text-xl text-primary-100 mb-8">
              Future-proof your property with professional electric vehicle charging infrastructure through our partnership with EOS
            </p>
            <Link href="/signup">
              <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
                Get Started Today
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Easy Setup Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Hassle-Free Installation</h2>
            <p className="text-xl text-gray-600">
              We manage every detail from electrical assessment to final commissioning
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shield className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fully Managed Service</h3>
              <p className="text-gray-600">
                Our EOS partners handle electrical infrastructure, permitting, installation, and utility coordination—you focus on your business
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Clock className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Scheduled Around You</h3>
              <p className="text-gray-600">
                Installations planned during low-traffic periods to minimize impact on tenants, guests, or employees
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Scalable Solutions</h3>
              <p className="text-gray-600">
                Start with a single charger or deploy dozens—infrastructure designed to grow with your needs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Legal Compliance Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-xl mb-4">
                <FileCheck className="text-green-600" size={32} />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Fully Code-Compliant & Certified</h2>
              <p className="text-xl text-gray-600">
                Every installation meets electrical codes, safety standards, and ADA accessibility requirements
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">NEC & Local Electrical Codes</h3>
                <p className="text-gray-600">
                  All work performed to National Electrical Code standards and local electrical requirements by licensed electricians
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">UL-Listed Equipment</h3>
                <p className="text-gray-600">
                  Only Underwriters Laboratories certified charging stations that meet rigorous safety and performance standards
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">ADA Accessibility Compliance</h3>
                <p className="text-gray-600">
                  Installations designed to meet Americans with Disabilities Act requirements for accessible EV charging
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Permitting & Inspections</h3>
                <p className="text-gray-600">
                  We handle all building permits, utility applications, and code inspections to ensure full legal compliance
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Professional EV Charging Solutions</h2>
            <p className="text-xl text-gray-600">
              Commercial-grade infrastructure that adds value to your property
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Level 2 Fast Charging</h3>
              <p className="text-gray-600">
                240V charging stations deliver up to 80 amps for fast, reliable charging up to 8x faster than standard outlets
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Integrated Loyalty Programs</h3>
              <p className="text-gray-600">
                Reward programs and consumer benefits that drive repeat usage and enhance customer engagement at your charging locations
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Networked Management</h3>
              <p className="text-gray-600">
                Cloud-based platform for remote monitoring, usage tracking, access control, and billing integration
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Load Management</h3>
              <p className="text-gray-600">
                Smart load balancing distributes power efficiently across multiple chargers without overloading your electrical service
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Revenue Opportunities</h3>
              <p className="text-gray-600">
                Monetize your charging infrastructure with flexible pricing models and payment processing integration
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Ongoing Support</h3>
              <p className="text-gray-600">
                24/7 technical support, preventive maintenance, and warranty coverage keep your chargers operational
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="section-padding bg-primary-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Property Benefits</h2>
            <p className="text-xl text-gray-600">
              EV charging infrastructure delivers measurable value to property owners
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Increase Property Value</h3>
              <p className="text-gray-600">
                EV charging amenities make properties more attractive to buyers and command premium rents or sale prices
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Attract & Retain Tenants</h3>
              <p className="text-gray-600">
                Meet growing demand from EV owners and demonstrate commitment to sustainability
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Generate Revenue</h3>
              <p className="text-gray-600">
                Create a new income stream through charging fees or build the cost into premium parking rates
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Future-Proof Infrastructure</h3>
              <p className="text-gray-600">
                Stay ahead of evolving regulations and market demands as EV adoption accelerates nationwide
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Sustainability Leadership</h3>
              <p className="text-gray-600">
                Enhance your environmental credentials and meet corporate sustainability goals
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <TrendingUp className="text-primary-600 mb-3" size={28} />
              <h3 className="text-xl font-semibold mb-3">Tax Incentives & Rebates</h3>
              <p className="text-gray-600">
                Access federal tax credits and state/local incentive programs that offset installation costs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Add EV Charging?
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Get a free electrical assessment and customized EV charging proposal through our EOS partnership
          </p>
          <Link href="/signup">
            <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
              Request Your Free Assessment
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
