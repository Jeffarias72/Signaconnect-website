import { Link } from 'wouter';
import { Shield, CheckCircle, Clock, FileCheck, Signal } from 'lucide-react';
import { useEffect } from 'react';

export default function CarrierEnhancementPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-20">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-6 flex justify-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-16 md:h-20 w-auto drop-shadow-lg"
              />
            </div>
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-2xl mb-6">
              <Shield size={40} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Carrier Enhancement Solutions</h1>
            <p className="text-xl text-primary-100 mb-8">
              Eliminate dead zones and ensure reliable cellular connectivity throughout your property by leveraging your WiFi network
            </p>
            <Link href="/signup">
              <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
                Get Started Today
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Easy Setup Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Seamless Installation Process</h2>
            <p className="text-xl text-gray-600">
              We make cellular enhancement effortless—no carrier negotiations, no technical headaches
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Clock className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Zero Downtime</h3>
              <p className="text-gray-600">
                Installation scheduled at your convenience with no disruption to daily operations or tenant activities
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shield className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Complete Turnkey Service</h3>
              <p className="text-gray-600">
                We handle site surveys, equipment selection, installation, carrier coordination, and ongoing maintenance
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Signal className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">All Carriers Supported</h3>
              <p className="text-gray-600">
                Simultaneous enhancement for Verizon, AT&T, T-Mobile, and other major carriers—no need to choose
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Legal Compliance Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-xl mb-4">
                <FileCheck className="text-green-600" size={32} />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Built for Compliance & Reliability</h2>
              <p className="text-xl text-gray-600">
                WiFi-based carrier enhancement that works seamlessly with existing infrastructure
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Carrier Network Integration</h3>
                <p className="text-gray-600">
                  Works directly with carrier networks to provide seamless voice, text, and data services over your WiFi infrastructure
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">WiFi Calling Support</h3>
                <p className="text-gray-600">
                  Enables native WiFi calling features on smartphones, providing crystal-clear voice quality without additional apps
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Network Security</h3>
                <p className="text-gray-600">
                  Enterprise-grade WiFi security ensures encrypted, protected carrier traffic across your network
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Seamless Handoff</h3>
                <p className="text-gray-600">
                  Automatic transition between WiFi and cellular networks as users move throughout your property
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">WiFi-Powered Carrier Connectivity</h2>
            <p className="text-xl text-gray-600">
              Leverage your existing WiFi network to provide reliable cellular service throughout your building
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">WiFi Network Optimization</h3>
              <p className="text-gray-600">
                Configure your existing WiFi infrastructure to support carrier voice and data services seamlessly
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">All Services Supported</h3>
              <p className="text-gray-600">
                Enable voice calls, text messaging, and high-speed data through WiFi-based carrier connectivity
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Multi-Carrier Support</h3>
              <p className="text-gray-600">
                Compatible with all major carriers—Verizon, AT&T, T-Mobile, and regional providers supporting WiFi calling
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Scalable Coverage</h3>
              <p className="text-gray-600">
                Expand carrier connectivity wherever your WiFi reaches—from small offices to large multi-story buildings
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Quality of Service</h3>
              <p className="text-gray-600">
                Prioritize carrier traffic to ensure consistent voice quality and data performance across your network
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Remote Monitoring</h3>
              <p className="text-gray-600">
                24/7 system health monitoring with proactive alerts and remote diagnostics
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="section-padding bg-primary-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ideal For</h2>
            <p className="text-xl text-gray-600">
              Properties where reliable cellular connectivity is essential
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Office Buildings</h3>
              <p className="text-gray-600">
                Ensure employees can make calls and access mobile data from anywhere in the building, improving productivity and satisfaction
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Multi-Family Residential</h3>
              <p className="text-gray-600">
                Provide tenants with strong cellular coverage as an amenity, increasing property value and resident retention
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Hotels & Hospitality</h3>
              <p className="text-gray-600">
                Deliver reliable mobile service to guests throughout your property, enhancing their experience and online reviews
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Healthcare Facilities</h3>
              <p className="text-gray-600">
                Enable staff and patient communication in critical areas where cellular signals typically struggle to penetrate
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Warehouses & Industrial</h3>
              <p className="text-gray-600">
                Maintain mobile connectivity in large metal buildings where signals are blocked by construction materials
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">CPG and Retail</h3>
              <p className="text-gray-600">
                Ensure customers and staff stay connected throughout stores and shopping centers for mobile payments, inventory management, and customer service
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Eliminate Dead Zones Today
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Get a free site assessment and customized cellular enhancement proposal
          </p>
          <Link href="/signup">
            <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
              Request Your Free Assessment
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
