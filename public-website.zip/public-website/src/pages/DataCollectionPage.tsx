import { Link } from 'wouter';
import { Users, CheckCircle, Clock, FileCheck, Shield, BarChart } from 'lucide-react';
import { useEffect } from 'react';

export default function DataCollectionPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-20">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-6 flex justify-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-16 md:h-20 w-auto drop-shadow-lg"
              />
            </div>
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-2xl mb-6">
              <Users size={40} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Data Collection Services</h1>
            <p className="text-xl text-primary-100 mb-8">
              Transform network data into actionable insights with privacy-compliant analytics and reporting solutions
            </p>
            <Link href="/signup">
              <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
                Get Started Today
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Easy Setup Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Effortless Implementation</h2>
            <p className="text-xl text-gray-600">
              We handle all technical setup and configuration—analytics start flowing immediately
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Clock className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Simple Deployment</h3>
              <p className="text-gray-600">
                Our team installs specialized hardware and configures the analytics platform—ready to collect data within days
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shield className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fully Automated</h3>
              <p className="text-gray-600">
                Real-time data collection and processing happens automatically in the background—no manual reporting needed
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <BarChart className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Custom Dashboards</h3>
              <p className="text-gray-600">
                Tailored reporting interfaces designed for your specific business needs and stakeholder requirements
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Legal Compliance Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-xl mb-4">
                <FileCheck className="text-green-600" size={32} />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">100% Privacy Compliant</h2>
              <p className="text-xl text-gray-600">
                Data collection designed to meet GDPR, CCPA, and all applicable privacy regulations
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">GDPR & CCPA Compliant</h3>
                <p className="text-gray-600">
                  All data collection methods comply with European GDPR and California CCPA privacy protection standards
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Anonymous Data Collection</h3>
                <p className="text-gray-600">
                  User analytics are aggregated and anonymized—no personally identifiable information is stored or tracked
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Built for Compliance</h3>
                <p className="text-gray-600">
                  Our data collection systems are architected from the ground up to meet privacy regulations and security best practices
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Data Retention Policies</h3>
                <p className="text-gray-600">
                  Configurable retention windows ensure data is only stored as long as necessary and securely purged afterward
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Analytics Capabilities</h2>
            <p className="text-xl text-gray-600">
              Comprehensive insights that drive better network planning and business decisions
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Real-Time Performance</h3>
              <p className="text-gray-600">
                See exactly how people move through your physical spaces with live occupancy data, dwell times, and traffic flow patterns
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Usage Analytics</h3>
              <p className="text-gray-600">
                Track total connected devices, bandwidth consumption, and traffic patterns by time of day
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Trend Analysis</h3>
              <p className="text-gray-600">
                Identify growth patterns, seasonal variations, and long-term usage trends for capacity planning
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Coverage Heatmaps</h3>
              <p className="text-gray-600">
                Visual representations of signal strength and usage density across your property
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Custom Reporting</h3>
              <p className="text-gray-600">
                Automated reports tailored for IT, management, or executive stakeholders with relevant KPIs
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">ROI Tracking</h3>
              <p className="text-gray-600">
                Measure the business impact and return on investment of your network infrastructure
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="section-padding bg-primary-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Data-Driven Decision Making</h2>
            <p className="text-xl text-gray-600">
              Use physical site insights to optimize operations and plan for the future
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Optimize Resource Allocation</h3>
              <p className="text-gray-600">
                Identify high-traffic areas that need additional staffing, infrastructure, or space redesigns to improve visitor experience
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Proactive Issue Resolution</h3>
              <p className="text-gray-600">
                Detect performance degradation before users complain and resolve issues faster with diagnostic data
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Capacity Planning</h3>
              <p className="text-gray-600">
                Forecast future bandwidth needs based on growth trends to plan infrastructure upgrades strategically
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Justify Infrastructure Investments</h3>
              <p className="text-gray-600">
                Use concrete data to demonstrate site performance and secure budget approval for facility enhancements
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Benchmarking & SLAs</h3>
              <p className="text-gray-600">
                Measure actual performance against service level agreements and industry benchmarks
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Visitor Behavior Insights</h3>
              <p className="text-gray-600">
                Understand peak traffic times and movement patterns to optimize layouts, signage, and operational efficiency
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Unlock the Power of Your Site Data
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Get a free analytics platform demo and see how data-driven insights can improve your physical spaces
          </p>
          <Link href="/signup">
            <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
              Request Your Free Demo
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
