import { Link } from 'wouter';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-200">
        <div className="container-custom py-4">
          <Link href="/">
            <a className="flex items-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-10 w-auto"
              />
            </a>
          </Link>
        </div>
      </header>

      <main className="container-custom py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
        <p className="text-gray-600 mb-8">Effective Date: November 13, 2025</p>

        <div className="prose prose-lg max-w-none">
          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
            <p className="text-gray-700 mb-4">
              SignaConnect ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
            </p>
            <p className="text-gray-700">
              By using our website or services, you agree to the collection and use of information in accordance with this Privacy Policy.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Information We Collect</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">2.1 Information You Provide</h3>
            <p className="text-gray-700 mb-4">
              We collect information that you voluntarily provide to us when you:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Register for our services through the signup form</li>
              <li>Contact us for customer support</li>
              <li>Subscribe to our communications</li>
              <li>Submit forms or inquiries on our website</li>
            </ul>
            <p className="text-gray-700 mb-4">
              This information may include:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Company name and business information</li>
              <li>Contact details (name, email address, phone number)</li>
              <li>Job title and department</li>
              <li>Physical addresses and location information</li>
              <li>Service preferences and requirements</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">2.2 Automatically Collected Information</h3>
            <p className="text-gray-700 mb-4">
              When you visit our website, we may automatically collect:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>IP address and device information</li>
              <li>Browser type and version</li>
              <li>Pages viewed and time spent on pages</li>
              <li>Referring website addresses</li>
              <li>Operating system and platform information</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. How We Use Your Information</h2>
            <p className="text-gray-700 mb-4">
              We use the information we collect for the following purposes:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li><strong>Service Delivery:</strong> To provide, maintain, and improve our Wi-Fi management services</li>
              <li><strong>Customer Support:</strong> To respond to your inquiries and provide technical support</li>
              <li><strong>Communications:</strong> To send service updates, newsletters, and marketing materials (with your consent)</li>
              <li><strong>Analytics:</strong> To understand how our services are used and improve user experience</li>
              <li><strong>Legal Compliance:</strong> To comply with applicable laws, regulations, and legal processes</li>
              <li><strong>Business Operations:</strong> To manage accounts, process payments, and maintain records</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">3.1 Legal Bases for Processing (GDPR)</h3>
            <p className="text-gray-700 mb-4">
              For users in the European Economic Area, we process your personal data based on the following legal grounds:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li><strong>Contract Performance:</strong> Processing necessary to perform our service agreement with you (e.g., delivering Wi-Fi installation services, managing your account)</li>
              <li><strong>Legitimate Interest:</strong> Processing necessary for our legitimate business interests (e.g., improving services, preventing fraud, securing our systems) that do not override your fundamental rights</li>
              <li><strong>Consent:</strong> When you have given explicit consent (e.g., marketing communications, newsletter subscriptions) - you may withdraw consent at any time</li>
              <li><strong>Legal Obligation:</strong> Processing necessary to comply with legal requirements (e.g., tax records, regulatory compliance)</li>
            </ul>
            <p className="text-gray-700">
              You have the right to object to processing based on legitimate interests. Please contact us to exercise this right.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Data Sharing and Disclosure</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">4.1 Third-Party Service Providers</h3>
            <p className="text-gray-700 mb-4">
              We may share your information with trusted third-party service providers who assist us in operating our business, including:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Cloud hosting and storage providers</li>
              <li>Email and communication platforms</li>
              <li>Payment processors</li>
              <li>Analytics and monitoring services</li>
            </ul>
            <p className="text-gray-700 mb-4">
              These providers are contractually obligated to protect your information and use it only for the services they provide to us.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">4.2 Legal Requirements</h3>
            <p className="text-gray-700 mb-4">
              We may disclose your information if required to do so by law or in response to valid requests by public authorities (e.g., court orders, subpoenas, or government regulations).
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">4.3 Business Transfers</h3>
            <p className="text-gray-700 mb-4">
              In the event of a merger, acquisition, or sale of assets, your information may be transferred to the acquiring entity. We will notify you of any such change in ownership or control.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">4.4 We Do Not Sell Personal Information</h3>
            <p className="text-gray-700 mb-4">
              <strong>SignaConnect does not sell, rent, or trade your personal information to third parties for their marketing purposes.</strong>
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Data Retention</h2>
            <p className="text-gray-700 mb-4">
              We retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required or permitted by law.
            </p>
            <p className="text-gray-700 mb-4">
              Specifically:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li><strong>Active customers:</strong> Data retained for the duration of the business relationship</li>
              <li><strong>Inactive accounts:</strong> Data retained for up to 3 years after last activity for business records</li>
              <li><strong>Marketing communications:</strong> Retained until you opt out</li>
              <li><strong>Legal obligations:</strong> Retained as required by applicable law (e.g., tax records for 7 years)</li>
            </ul>
            <p className="text-gray-700">
              After the retention period, we will securely delete or anonymize your personal information.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Your Privacy Rights</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">6.1 General Rights</h3>
            <p className="text-gray-700 mb-4">
              You have the following rights regarding your personal information:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li><strong>Access:</strong> Request a copy of the personal information we hold about you</li>
              <li><strong>Correction:</strong> Request correction of inaccurate or incomplete information</li>
              <li><strong>Deletion:</strong> Request deletion of your personal information (subject to legal obligations)</li>
              <li><strong>Opt-Out:</strong> Unsubscribe from marketing communications at any time</li>
              <li><strong>Data Portability:</strong> Receive your data in a structured, machine-readable format</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">6.2 California Privacy Rights (CCPA)</h3>
            <p className="text-gray-700 mb-4">
              If you are a California resident, you have additional rights under the California Consumer Privacy Act (CCPA):
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Right to know what personal information is collected, used, shared, or sold</li>
              <li>Right to delete personal information (subject to exceptions)</li>
              <li>Right to opt-out of the sale of personal information (we do not sell personal information)</li>
              <li>Right to non-discrimination for exercising your CCPA rights</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">6.3 European Privacy Rights (GDPR)</h3>
            <p className="text-gray-700 mb-4">
              If you are located in the European Economic Area (EEA), you have rights under the General Data Protection Regulation (GDPR):
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Right to access your personal data</li>
              <li>Right to rectification of inaccurate data</li>
              <li>Right to erasure ("right to be forgotten")</li>
              <li>Right to restrict processing</li>
              <li>Right to data portability</li>
              <li>Right to object to processing</li>
              <li>Right to withdraw consent at any time</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">6.4 How to Exercise Your Rights</h3>
            <p className="text-gray-700 mb-4">
              To exercise any of these rights, please contact us at:
            </p>
            <p className="text-gray-700 mb-4">
              Email: <a href="mailto:info@signaconnect.com" className="text-primary-600 hover:text-primary-700">info@signaconnect.com</a><br />
              Phone: <a href="tel:9085324503" className="text-primary-600 hover:text-primary-700">(908) 532-4503</a>
            </p>
            <p className="text-gray-700">
              We will respond to your request within 30 days (or as required by applicable law).
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Marketing Communications and Opt-Out</h2>
            <p className="text-gray-700 mb-4">
              You may opt out of receiving marketing communications from us at any time by:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Clicking the "unsubscribe" link in any marketing email</li>
              <li>Contacting us at <a href="mailto:info@signaconnect.com" className="text-primary-600 hover:text-primary-700">info@signaconnect.com</a></li>
              <li>Updating your communication preferences in your account settings</li>
            </ul>
            <p className="text-gray-700">
              Please note that even if you opt out of marketing communications, we may still send you transactional or service-related messages (e.g., account notifications, service updates).
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Data Security</h2>
            <p className="text-gray-700 mb-4">
              We implement appropriate technical and organizational security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. These measures include:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Encryption of data in transit and at rest</li>
              <li>Regular security assessments and audits</li>
              <li>Access controls and authentication mechanisms</li>
              <li>Employee training on data protection practices</li>
              <li>Secure data centers and infrastructure</li>
            </ul>
            <p className="text-gray-700">
              However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to protect your information, we cannot guarantee absolute security.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Cookies and Tracking Technologies</h2>
            <p className="text-gray-700 mb-4">
              Our website may use cookies and similar tracking technologies to enhance user experience and analyze website traffic. You can control cookie settings through your browser preferences.
            </p>
            <p className="text-gray-700 mb-4">
              Types of cookies we use:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li><strong>Essential cookies:</strong> Required for website functionality</li>
              <li><strong>Analytics cookies:</strong> Help us understand how visitors use our site</li>
              <li><strong>Preference cookies:</strong> Remember your settings and preferences</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Children's Privacy</h2>
            <p className="text-gray-700">
              Our services are not directed to individuals under the age of 18. We do not knowingly collect personal information from children. If you believe we have inadvertently collected information from a child, please contact us immediately.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Changes to This Privacy Policy</h2>
            <p className="text-gray-700 mb-4">
              We may update this Privacy Policy from time to time to reflect changes in our practices or applicable laws. We will notify you of any material changes by:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Posting the updated policy on our website with a new effective date</li>
              <li>Sending you an email notification (if you have provided your email address)</li>
            </ul>
            <p className="text-gray-700">
              Your continued use of our services after any changes indicates your acceptance of the updated Privacy Policy.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Contact Information</h2>
            <p className="text-gray-700 mb-4">
              If you have any questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us:
            </p>
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-700 mb-2"><strong>SignaConnect</strong></p>
              <p className="text-gray-700 mb-2">Email: <a href="mailto:info@signaconnect.com" className="text-primary-600 hover:text-primary-700">info@signaconnect.com</a></p>
              <p className="text-gray-700 mb-2">Phone: <a href="tel:9085324503" className="text-primary-600 hover:text-primary-700">(908) 532-4503</a></p>
              <p className="text-gray-700">Website: <a href="https://signaconnect.com" className="text-primary-600 hover:text-primary-700">www.signaconnect.com</a></p>
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t border-gray-200 mt-16">
        <div className="container-custom py-8">
          <p className="text-center text-gray-600 text-sm">
            © 2025 SignaConnect. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
