import { useEffect, useState } from 'react';
import { useRoute } from 'wouter';
import { FileText, AlertCircle, Loader2 } from 'lucide-react';
import { getContractByToken, ContractDetails } from '@/lib/api';

export default function ContractPortalPage() {
  const [, params] = useRoute('/contract/:token');
  const token = params?.token || '';

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [contractData, setContractData] = useState<ContractDetails | null>(null);

  useEffect(() => {
    if (!token) {
      setError('Invalid contract link');
      setLoading(false);
      return;
    }

    const fetchContract = async () => {
      try {
        const data = await getContractByToken(token);
        setContractData(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load contract');
      } finally {
        setLoading(false);
      }
    };

    fetchContract();
  }, [token]);

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="animate-spin text-primary-600 mx-auto mb-4" size={48} />
          <p className="text-gray-600">Loading contract...</p>
        </div>
      </div>
    );
  }

  if (error || !contractData) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full bg-white p-8 rounded-xl shadow-lg text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="text-red-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold mb-4">Contract Not Found</h2>
          <p className="text-gray-600 mb-4">
            {error || 'The contract link you\'re trying to access is invalid or has expired.'}
          </p>
          <p className="text-sm text-gray-500">
            If you believe this is an error, please contact SignaConnect support at{' '}
            <a href="tel:9085324503" className="text-primary-600 hover:underline">
              (908) 532-4503
            </a>
          </p>
        </div>
      </div>
    );
  }

  const { signatureRequest, company, deal } = contractData;

  return (
    <div className="section-padding bg-gray-50">
      <div className="container-custom max-w-3xl">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6 pb-6 border-b">
            <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
              <FileText className="text-primary-600" size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{signatureRequest.contractTitle}</h1>
              <p className="text-gray-600">Contract Signature Request</p>
            </div>
          </div>

          {/* Contract Details */}
          <div className="space-y-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Company</h3>
                <p className="text-lg font-semibold">{company.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Project</h3>
                <p className="text-lg font-semibold">{deal.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Signer</h3>
                <p className="text-lg">{signatureRequest.signerName}</p>
                <p className="text-sm text-gray-600">{signatureRequest.signerEmail}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Status</h3>
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                  signatureRequest.status === 'signed' 
                    ? 'bg-green-100 text-green-800'
                    : signatureRequest.status === 'pending' || signatureRequest.status === 'sent'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {signatureRequest.status.charAt(0).toUpperCase() + signatureRequest.status.slice(1)}
                </span>
              </div>
            </div>

            {/* Status-specific messages */}
            {signatureRequest.status === 'signed' && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 font-medium">
                  This contract has already been signed. Thank you!
                </p>
              </div>
            )}

            {(signatureRequest.status === 'pending' || signatureRequest.status === 'sent') && signatureRequest.signPageUrl && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="font-semibold mb-2">Ready to Sign</h3>
                <p className="text-gray-700 mb-4">
                  Please review the contract and provide your electronic signature.
                </p>
                <a
                  href={signatureRequest.signPageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary"
                  data-testid="button-sign-contract"
                >
                  <FileText size={20} />
                  Sign Contract
                </a>
              </div>
            )}

            {(signatureRequest.status === 'pending' || signatureRequest.status === 'sent') && !signatureRequest.signPageUrl && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800">
                  The signature link is being prepared. Please check back shortly or contact SignaConnect if this persists.
                </p>
              </div>
            )}

            {signatureRequest.status === 'declined' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800 font-medium mb-2">This contract has been declined.</p>
                <p className="text-red-700 text-sm">
                  If you need to discuss this further, please contact our team.
                </p>
              </div>
            )}
          </div>

          {/* Contact Information */}
          <div className="border-t pt-6">
            <h3 className="font-semibold mb-3">Need Help?</h3>
            <p className="text-gray-600 mb-3">
              If you have any questions about this contract, please contact us:
            </p>
            <div className="space-y-2">
              <p className="text-gray-700">
                <span className="font-medium">Phone:</span>{' '}
                <a href="tel:9085324503" className="text-primary-600 hover:underline">
                  (908) 532-4503
                </a>
              </p>
              <p className="text-gray-700">
                <span className="font-medium">Email:</span>{' '}
                <a href="mailto:info@signaconnect.com" className="text-primary-600 hover:underline">
                  info@signaconnect.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
