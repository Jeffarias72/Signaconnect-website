import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { ChevronLeft, ChevronRight, Upload, Plus, Trash2, CheckCircle } from 'lucide-react';
import Papa from 'papaparse';
import { submitSignup, SignupLocation, SignupPayload } from '@/lib/api';

interface FormData {
  // Company
  companyName: string;
  website: string;
  companyType: string;
  companyPhone: string;
  companyEmail: string;
  estimatedStartDate: string;
  
  // Contact
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  jobTitle: string;
  
  // Other
  marketingOptIn: boolean;
  message: string;
}

const SERVICE_TYPES = [
  'Wi-Fi Network Installation',
  'Carrier Enhancement',
  'EV Installation',
  'Data Collection',
  'Network Infrastructure',
  'Access Point Installation',
  'Site Survey',
  'Network Configuration',
  'Coverage Analysis',
  'Signal Optimization',
  'Equipment Procurement',
  'Maintenance & Support'
];

export default function SignupPage() {
  const [step, setStep] = useState(1);
  const [locations, setLocations] = useState<SignupLocation[]>([]);
  const [csvError, setCsvError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const { register, handleSubmit, formState: { errors }, watch } = useForm<FormData>({
    defaultValues: {
      marketingOptIn: false,
    },
  });

  const addLocation = () => {
    setLocations([...locations, {
      siteName: '',
      serviceType: 'Carrier Enhancement',
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      zipCode: '',
      notes: '',
      desiredStartDate: '',
    }]);
  };

  const removeLocation = (index: number) => {
    setLocations(locations.filter((_, i) => i !== index));
  };

  const updateLocation = (index: number, field: keyof SignupLocation, value: string) => {
    const updated = [...locations];
    updated[index] = { ...updated[index], [field]: value };
    setLocations(updated);
  };

  const handleCsvUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setCsvError(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const parsedLocations: SignupLocation[] = results.data.map((row: any, index: number) => {
            // Normalize column names (handle variations)
            const normalizedRow: any = {};
            Object.keys(row).forEach(key => {
              const normalized = key.toLowerCase().replace(/[\s_-]/g, '');
              normalizedRow[normalized] = row[key];
            });

            const siteName = normalizedRow.sitename || normalizedRow.name || '';
            const addressLine1 = normalizedRow.address || normalizedRow.addressline1 || normalizedRow.street || '';
            const city = normalizedRow.city || '';
            const state = normalizedRow.state || '';
            const zipCode = normalizedRow.zip || normalizedRow.zipcode || normalizedRow.postalcode || '';

            if (!siteName || !addressLine1 || !city || !state || !zipCode) {
              throw new Error(`Row ${index + 1}: Missing required fields (siteName, address, city, state, zipCode)`);
            }

            return {
              siteName,
              serviceType: normalizedRow.servicetype || normalizedRow.service || 'Carrier Enhancement',
              addressLine1,
              addressLine2: normalizedRow.addressline2 || normalizedRow.address2 || null,
              city,
              state,
              zipCode,
              notes: normalizedRow.notes || normalizedRow.comments || null,
              desiredStartDate: normalizedRow.desiredstartdate || normalizedRow.startdate || null,
            };
          });

          setLocations([...locations, ...parsedLocations]);
        } catch (error) {
          setCsvError(error instanceof Error ? error.message : 'Failed to parse CSV file');
        }
      },
      error: (error) => {
        setCsvError(`CSV parsing error: ${error.message}`);
      },
    });

    // Reset input
    event.target.value = '';
  };

  const onSubmit = async (data: FormData) => {
    if (locations.length === 0) {
      setSubmitError('Please add at least one location');
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    try {
      const payload: SignupPayload = {
        company: {
          companyName: data.companyName,
          website: data.website || null,
          companyType: data.companyType || null,
          phone: data.companyPhone || null,
          email: data.companyEmail || null,
          estimatedStartDate: data.estimatedStartDate || null,
        },
        contact: {
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
          phone: data.phone,
          jobTitle: data.jobTitle || null,
        },
        locations,
        marketingOptIn: data.marketingOptIn,
        message: data.message || null,
      };

      await submitSignup(payload);
      setSubmitSuccess(true);
    } catch (error) {
      setSubmitError(error instanceof Error ? error.message : 'Failed to submit signup');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitSuccess) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full bg-white p-8 rounded-xl shadow-lg text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="text-green-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold mb-4">Thank You!</h2>
          <p className="text-gray-600 mb-6">
            Your request has been submitted successfully. Our team will review your information
            and contact you shortly to discuss next steps.
          </p>
          <p className="text-sm text-gray-500">
            You should receive a confirmation email at {watch('email')} within the next few minutes.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="section-padding bg-gray-50">
      <div className="container-custom max-w-4xl">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Logo */}
          <div className="mb-6 flex justify-center">
            <img 
              src="/signaconnect-logo.png" 
              alt="SignaConnect Logo" 
              className="h-16 md:h-20 w-auto"
            />
          </div>
          <h1 className="text-3xl font-bold mb-2 text-center">Get Started with SignaConnect</h1>
          <p className="text-gray-600 mb-8">
            Complete the form below to request a consultation. We'll review your needs and contact you with a customized solution.
          </p>

          {/* Progress Indicator */}
          <div className="flex items-center justify-between mb-8">
            <div className={`flex-1 ${step >= 1 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-full h-2 rounded-full ${step >= 1 ? 'bg-primary-600' : 'bg-gray-200'}`} />
              <p className="text-sm mt-2 font-medium">Company Info</p>
            </div>
            <div className={`flex-1 ml-4 ${step >= 2 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-full h-2 rounded-full ${step >= 2 ? 'bg-primary-600' : 'bg-gray-200'}`} />
              <p className="text-sm mt-2 font-medium">Contact Info</p>
            </div>
            <div className={`flex-1 ml-4 ${step >= 3 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-full h-2 rounded-full ${step >= 3 ? 'bg-primary-600' : 'bg-gray-200'}`} />
              <p className="text-sm mt-2 font-medium">Locations</p>
            </div>
            <div className={`flex-1 ml-4 ${step >= 4 ? 'text-primary-600' : 'text-gray-400'}`}>
              <div className={`w-full h-2 rounded-full ${step >= 4 ? 'bg-primary-600' : 'bg-gray-200'}`} />
              <p className="text-sm mt-2 font-medium">Review</p>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Step 1: Company Information */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Company Name *</label>
                  <input
                    type="text"
                    {...register('companyName', { required: 'Company name is required' })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    data-testid="input-company-name"
                  />
                  {errors.companyName && <p className="text-red-500 text-sm mt-1">{errors.companyName.message}</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Company Website</label>
                    <input
                      type="url"
                      {...register('website')}
                      placeholder="https://example.com"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-website"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Company Type</label>
                    <input
                      type="text"
                      {...register('companyType')}
                      placeholder="e.g., Hotel, Office Building"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-company-type"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Company Phone</label>
                    <input
                      type="tel"
                      {...register('companyPhone')}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-company-phone"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Company Email</label>
                    <input
                      type="email"
                      {...register('companyEmail')}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-company-email"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Estimated Start Date</label>
                  <input
                    type="date"
                    {...register('estimatedStartDate')}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    data-testid="input-estimated-start-date"
                  />
                </div>
              </div>
            )}

            {/* Step 2: Contact Information */}
            {step === 2 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">First Name *</label>
                    <input
                      type="text"
                      {...register('firstName', { required: 'First name is required' })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-first-name"
                    />
                    {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Last Name *</label>
                    <input
                      type="text"
                      {...register('lastName', { required: 'Last name is required' })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-last-name"
                    />
                    {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Email Address *</label>
                  <input
                    type="email"
                    {...register('email', {
                      required: 'Email is required',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: 'Invalid email address',
                      },
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    data-testid="input-email"
                  />
                  {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      {...register('phone', { required: 'Phone number is required' })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-phone"
                    />
                    {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Job Title</label>
                    <input
                      type="text"
                      {...register('jobTitle')}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      data-testid="input-job-title"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Locations */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Service Locations</h3>
                  <div className="flex gap-2">
                    <label className="btn btn-secondary cursor-pointer">
                      <Upload size={20} />
                      Upload CSV
                      <input
                        type="file"
                        accept=".csv"
                        onChange={handleCsvUpload}
                        className="hidden"
                        data-testid="input-csv-upload"
                      />
                    </label>
                    <button type="button" onClick={addLocation} className="btn btn-primary" data-testid="button-add-location">
                      <Plus size={20} />
                      Add Location
                    </button>
                  </div>
                </div>

                {csvError && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                    {csvError}
                  </div>
                )}

                <div className="space-y-4">
                  {locations.map((location, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                      <div className="flex justify-between items-center mb-3">
                        <h4 className="font-medium">Location {index + 1}</h4>
                        <button
                          type="button"
                          onClick={() => removeLocation(index)}
                          className="text-red-600 hover:text-red-700"
                          data-testid={`button-remove-location-${index}`}
                        >
                          <Trash2 size={20} />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-sm font-medium mb-1">Site Name *</label>
                          <input
                            type="text"
                            value={location.siteName}
                            onChange={(e) => updateLocation(index, 'siteName', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            required
                            data-testid={`input-site-name-${index}`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Service Type *</label>
                          <select
                            value={location.serviceType}
                            onChange={(e) => updateLocation(index, 'serviceType', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            required
                            data-testid={`select-service-type-${index}`}
                          >
                            {SERVICE_TYPES.map(type => (
                              <option key={type} value={type}>{type}</option>
                            ))}
                          </select>
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-sm font-medium mb-1">Address Line 1 *</label>
                          <input
                            type="text"
                            value={location.addressLine1}
                            onChange={(e) => updateLocation(index, 'addressLine1', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            required
                            data-testid={`input-address1-${index}`}
                          />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-sm font-medium mb-1">Address Line 2</label>
                          <input
                            type="text"
                            value={location.addressLine2 || ''}
                            onChange={(e) => updateLocation(index, 'addressLine2', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            data-testid={`input-address2-${index}`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">City *</label>
                          <input
                            type="text"
                            value={location.city}
                            onChange={(e) => updateLocation(index, 'city', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            required
                            data-testid={`input-city-${index}`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">State *</label>
                          <input
                            type="text"
                            value={location.state}
                            onChange={(e) => updateLocation(index, 'state', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            maxLength={2}
                            required
                            data-testid={`input-state-${index}`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">ZIP Code *</label>
                          <input
                            type="text"
                            value={location.zipCode}
                            onChange={(e) => updateLocation(index, 'zipCode', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            required
                            data-testid={`input-zip-${index}`}
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-1">Desired Start Date</label>
                          <input
                            type="date"
                            value={location.desiredStartDate || ''}
                            onChange={(e) => updateLocation(index, 'desiredStartDate', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            data-testid={`input-start-date-${index}`}
                          />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-sm font-medium mb-1">Notes</label>
                          <textarea
                            value={location.notes || ''}
                            onChange={(e) => updateLocation(index, 'notes', e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                            rows={2}
                            data-testid={`textarea-notes-${index}`}
                          />
                        </div>
                      </div>
                    </div>
                  ))}

                  {locations.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <p>No locations added yet. Click "Add Location" or "Upload CSV" to get started.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Step 4: Review & Submit */}
            {step === 4 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Review Your Information</h3>
                  
                  <div className="bg-gray-50 rounded-lg p-4 mb-4">
                    <h4 className="font-medium mb-2">Company</h4>
                    <p className="text-sm text-gray-600">{watch('companyName')}</p>
                    {watch('website') && <p className="text-sm text-gray-600">{watch('website')}</p>}
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 mb-4">
                    <h4 className="font-medium mb-2">Contact</h4>
                    <p className="text-sm text-gray-600">{watch('firstName')} {watch('lastName')}</p>
                    <p className="text-sm text-gray-600">{watch('email')}</p>
                    <p className="text-sm text-gray-600">{watch('phone')}</p>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-4 mb-4">
                    <h4 className="font-medium mb-2">Locations ({locations.length})</h4>
                    {locations.map((loc, i) => (
                      <p key={i} className="text-sm text-gray-600">
                        {loc.siteName} - {loc.serviceType}
                      </p>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Additional Message</label>
                  <textarea
                    {...register('message')}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    rows={4}
                    placeholder="Tell us more about your project..."
                    data-testid="textarea-message"
                  />
                </div>

                <div className="flex items-start gap-2">
                  <input
                    type="checkbox"
                    {...register('marketingOptIn')}
                    className="mt-1"
                    data-testid="checkbox-marketing"
                  />
                  <label className="text-sm text-gray-600">
                    I would like to receive updates and marketing communications from SignaConnect
                  </label>
                </div>

                {submitError && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                    {submitError}
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              {step > 1 && (
                <button
                  type="button"
                  onClick={() => setStep(step - 1)}
                  className="btn btn-secondary"
                  data-testid="button-prev"
                >
                  <ChevronLeft size={20} />
                  Previous
                </button>
              )}
              
              {step < 4 ? (
                <button
                  type="button"
                  onClick={() => setStep(step + 1)}
                  className="btn btn-primary ml-auto"
                  data-testid="button-next"
                >
                  Next
                  <ChevronRight size={20} />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={isSubmitting || locations.length === 0}
                  className="btn btn-primary ml-auto disabled:opacity-50 disabled:cursor-not-allowed"
                  data-testid="button-submit"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
