import { Link } from 'wouter';

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-200">
        <div className="container-custom py-4">
          <Link href="/">
            <a className="flex items-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-10 w-auto"
              />
            </a>
          </Link>
        </div>
      </header>

      <main className="container-custom py-12 max-w-4xl">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Terms of Service</h1>
        <p className="text-gray-600 mb-8">Effective Date: November 13, 2025</p>

        <div className="prose prose-lg max-w-none">
          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-700 mb-4">
              Welcome to SignaConnect. By accessing or using our website and services, you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use our services.
            </p>
            <p className="text-gray-700">
              These Terms constitute a legally binding agreement between you and SignaConnect regarding your use of our Wi-Fi management and telecommunications services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Services Description</h2>
            <p className="text-gray-700 mb-4">
              SignaConnect provides Wi-Fi network management, telecommunications consulting, and related services including:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Wi-Fi network installation and configuration</li>
              <li>Carrier enhancement and optimization</li>
              <li>Electric vehicle (EV) charging infrastructure installation</li>
              <li>Data collection and analytics services</li>
              <li>Network monitoring and maintenance</li>
              <li>Technical support and consulting</li>
            </ul>
            <p className="text-gray-700">
              The specific scope of services will be defined in your service agreement or contract with SignaConnect.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Eligibility</h2>
            <p className="text-gray-700 mb-4">
              You must be at least 18 years old and have the authority to enter into these Terms on behalf of your business or organization. By using our services, you represent and warrant that you meet these eligibility requirements.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Account Registration</h2>
            <p className="text-gray-700 mb-4">
              To access certain services, you may be required to create an account. You agree to:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Provide accurate, current, and complete information during registration</li>
              <li>Maintain and promptly update your account information</li>
              <li>Maintain the security of your account credentials</li>
              <li>Notify us immediately of any unauthorized access or security breaches</li>
              <li>Accept responsibility for all activities that occur under your account</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Use of Services</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">5.1 Acceptable Use</h3>
            <p className="text-gray-700 mb-4">
              You agree to use our services only for lawful purposes and in accordance with these Terms. You agree not to:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Violate any applicable laws or regulations</li>
              <li>Infringe on the intellectual property rights of others</li>
              <li>Transmit harmful, malicious, or unauthorized code</li>
              <li>Interfere with or disrupt our services or servers</li>
              <li>Attempt to gain unauthorized access to our systems</li>
              <li>Use our services for fraudulent or deceptive purposes</li>
              <li>Harass, abuse, or harm other users</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">5.2 Service Modifications</h3>
            <p className="text-gray-700">
              We reserve the right to modify, suspend, or discontinue any aspect of our services at any time, with or without notice. We will not be liable to you or any third party for any modification, suspension, or discontinuation of services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Payment and Fees</h2>
            <p className="text-gray-700 mb-4">
              Certain services may require payment of fees. You agree to:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Pay all fees associated with your use of paid services</li>
              <li>Provide accurate and complete billing information</li>
              <li>Pay all applicable taxes</li>
              <li>Comply with the payment terms specified in your service agreement</li>
            </ul>
            <p className="text-gray-700 mb-4">
              Fees are non-refundable except as required by law or as specified in your service agreement. We reserve the right to change our fees at any time with reasonable notice.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Intellectual Property</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">7.1 Our Intellectual Property</h3>
            <p className="text-gray-700 mb-4">
              All content, features, and functionality of our website and services, including but not limited to text, graphics, logos, software, and designs, are owned by SignaConnect or our licensors and are protected by copyright, trademark, and other intellectual property laws.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">7.2 Limited License</h3>
            <p className="text-gray-700 mb-4">
              We grant you a limited, non-exclusive, non-transferable license to access and use our services for your internal business purposes. This license does not include the right to:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Reproduce, modify, or create derivative works</li>
              <li>Distribute, sell, or sublicense our content</li>
              <li>Reverse engineer or decompile our software</li>
              <li>Remove or alter any proprietary notices</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Confidentiality</h2>
            <p className="text-gray-700 mb-4">
              In the course of providing services, we may have access to confidential information about your business. We agree to maintain the confidentiality of such information and use it only for the purpose of providing services to you.
            </p>
            <p className="text-gray-700">
              Similarly, you agree to keep confidential any proprietary information, methodologies, or trade secrets you may learn about SignaConnect during our business relationship.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Warranties and Disclaimers</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">9.1 Service Warranties</h3>
            <p className="text-gray-700 mb-4">
              We strive to provide high-quality services and will perform our services in a professional and workmanlike manner. However, we do not guarantee that our services will be uninterrupted, error-free, or meet all of your specific requirements.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">9.2 Disclaimer</h3>
            <p className="text-gray-700 mb-4">
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, OUR SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Limitation of Liability</h2>
            <p className="text-gray-700 mb-4">
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL SIGNACONNECT, ITS OFFICERS, DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE FOR:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>Any indirect, incidental, special, consequential, or punitive damages</li>
              <li>Loss of profits, revenue, data, or business opportunities</li>
              <li>Service interruptions or data loss</li>
              <li>Third-party claims or damages</li>
            </ul>
            <p className="text-gray-700 mb-4">
              OUR TOTAL LIABILITY TO YOU FOR ANY CLAIMS ARISING OUT OF OR RELATED TO THESE TERMS OR OUR SERVICES SHALL NOT EXCEED THE AMOUNT YOU PAID TO US IN THE 12 MONTHS PRECEDING THE CLAIM.
            </p>
            <p className="text-gray-700">
              Some jurisdictions do not allow the exclusion or limitation of certain damages, so some of the above limitations may not apply to you.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Indemnification</h2>
            <p className="text-gray-700">
              You agree to indemnify, defend, and hold harmless SignaConnect and its officers, directors, employees, and agents from and against any claims, liabilities, damages, losses, and expenses (including reasonable attorneys' fees) arising out of or related to your use of our services, your violation of these Terms, or your violation of any rights of another party.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Term and Termination</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">12.1 Term</h3>
            <p className="text-gray-700 mb-4">
              These Terms remain in effect while you use our services or until terminated by either party.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">12.2 Termination by You</h3>
            <p className="text-gray-700 mb-4">
              You may terminate your account at any time by contacting us. Termination does not relieve you of any payment obligations for services already provided.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">12.3 Termination by Us</h3>
            <p className="text-gray-700 mb-4">
              We may suspend or terminate your access to our services immediately, without prior notice, if:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-700">
              <li>You violate these Terms</li>
              <li>Your account is inactive for an extended period</li>
              <li>We are required to do so by law</li>
              <li>We discontinue services to all users in your jurisdiction</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">12.4 Effect of Termination</h3>
            <p className="text-gray-700">
              Upon termination, your right to use our services will immediately cease. Sections of these Terms that by their nature should survive termination (including warranties, disclaimers, liability limitations, and dispute resolution) will survive.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">13. Dispute Resolution</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">13.1 Governing Law</h3>
            <p className="text-gray-700 mb-4">
              These Terms shall be governed by and construed in accordance with the laws of the Commonwealth of Pennsylvania, without regard to its conflict of law provisions.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">13.2 Arbitration</h3>
            <p className="text-gray-700 mb-4">
              Any dispute arising out of or relating to these Terms or our services shall be resolved through binding arbitration in accordance with the Commercial Arbitration Rules of the American Arbitration Association. The arbitration shall be conducted in Philadelphia, Pennsylvania.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">13.3 Class Action Waiver</h3>
            <p className="text-gray-700">
              You agree that any arbitration or legal proceeding shall be conducted on an individual basis and not as a class action, consolidated action, or representative action. You waive any right to participate in a class action lawsuit or class-wide arbitration.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">14. General Provisions</h2>
            
            <h3 className="text-xl font-semibold text-gray-900 mb-3">14.1 Entire Agreement</h3>
            <p className="text-gray-700 mb-4">
              These Terms, together with our Privacy Policy and any service agreements, constitute the entire agreement between you and SignaConnect regarding our services.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">14.2 Modifications</h3>
            <p className="text-gray-700 mb-4">
              We may modify these Terms at any time by posting the updated Terms on our website. Your continued use of our services after any such changes constitutes your acceptance of the new Terms.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">14.3 Severability</h3>
            <p className="text-gray-700 mb-4">
              If any provision of these Terms is found to be unenforceable or invalid, that provision shall be limited or eliminated to the minimum extent necessary, and the remaining provisions shall remain in full force and effect.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">14.4 Waiver</h3>
            <p className="text-gray-700 mb-4">
              Our failure to enforce any right or provision of these Terms shall not constitute a waiver of such right or provision.
            </p>

            <h3 className="text-xl font-semibold text-gray-900 mb-3">14.5 Assignment</h3>
            <p className="text-gray-700">
              You may not assign or transfer these Terms or your rights hereunder without our prior written consent. We may assign these Terms without restriction.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">15. Contact Information</h2>
            <p className="text-gray-700 mb-4">
              If you have any questions about these Terms of Service, please contact us:
            </p>
            <div className="bg-gray-50 p-6 rounded-lg">
              <p className="text-gray-700 mb-2"><strong>SignaConnect</strong></p>
              <p className="text-gray-700 mb-2">Email: <a href="mailto:info@signaconnect.com" className="text-primary-600 hover:text-primary-700">info@signaconnect.com</a></p>
              <p className="text-gray-700 mb-2">Phone: <a href="tel:9085324503" className="text-primary-600 hover:text-primary-700">(908) 532-4503</a></p>
              <p className="text-gray-700">Website: <a href="https://signaconnect.com" className="text-primary-600 hover:text-primary-700">www.signaconnect.com</a></p>
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t border-gray-200 mt-16">
        <div className="container-custom py-8">
          <p className="text-center text-gray-600 text-sm">
            © 2025 SignaConnect. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
