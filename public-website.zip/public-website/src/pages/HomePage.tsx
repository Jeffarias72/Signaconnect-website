import { Link } from 'wouter';
import { Wifi, TrendingUp, Zap, Shield, Users, CheckCircle } from 'lucide-react';

export default function HomePage() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative section-padding overflow-hidden">
        {/* Background Image with Blur */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(/hero-bg.jpg)',
            filter: 'blur(3px)',
            transform: 'scale(1.1)',
          }}
        />
        
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/70 to-gray-900/80" />
        
        {/* Content */}
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-8 flex justify-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-20 md:h-28 w-auto drop-shadow-lg"
              />
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">
              Wi-Fi That Works for You
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90">
              Powerful Wi-Fi. Proven Profit.
            </p>
            <p className="text-lg mb-8 text-white/80">
              Professional carrier enhancement, Wi-Fi network installation, and data collection services
              tailored for your business needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <a className="btn bg-white text-primary-600 hover:bg-gray-100 shadow-lg">
                  Get Started Today
                </a>
              </Link>
              <Link href="/services">
                <a className="btn btn-outline border-white text-white hover:bg-white/10 shadow-lg">
                  View Our Services
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Why Choose SignaConnect?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Wifi className="text-primary-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Expert Installation</h3>
              <p className="text-gray-600">
                Professional Wi-Fi network setup with carrier enhancement capabilities for maximum coverage and performance.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="text-primary-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Proven Results</h3>
              <p className="text-gray-600">
                Increase your property value and tenant satisfaction with reliable, high-speed wireless connectivity.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="text-primary-600" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fast Deployment</h3>
              <p className="text-gray-600">
                Quick turnaround times from initial consultation to full network deployment and data collection.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="section-padding">
        <div className="container-custom">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
            Our Core Services
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Link href="/services/carrier-enhancement">
              <a className="block border-2 border-gray-200 rounded-xl p-8 hover:border-primary-400 transition cursor-pointer" data-testid="service-carrier-enhancement">
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                  <Shield className="text-primary-600" />
                  Carrier Enhancement
                </h3>
                <p className="text-gray-600 mb-4">
                  Boost cellular signal strength and coverage throughout your property with our advanced
                  carrier enhancement solutions. Perfect for buildings with poor reception.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Improved cell signal coverage</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Enhanced data speeds</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Better call quality</span>
                  </li>
                </ul>
              </a>
            </Link>

            <Link href="/services/data-collection">
              <a className="block border-2 border-gray-200 rounded-xl p-8 hover:border-primary-400 transition cursor-pointer" data-testid="service-data-collection">
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                  <Users className="text-primary-600" />
                  Data Collection Services
                </h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive data collection and analysis to optimize network performance and
                  understand usage patterns for better decision-making.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Network analytics and reporting</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Usage pattern analysis</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Performance optimization insights</span>
                  </li>
                </ul>
              </a>
            </Link>

            <Link href="/services/ev-charging">
              <a className="block border-2 border-gray-200 rounded-xl p-8 hover:border-primary-400 transition cursor-pointer" data-testid="service-ev-charging">
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                  <Zap className="text-primary-600" />
                  EV Installation
                </h3>
                <p className="text-gray-600 mb-4">
                  Electric vehicle charging infrastructure installation in partnership with EOS,
                  adding value to your property and supporting sustainable transportation.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Level 2 and DC fast chargers</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Professional electrical work</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Compliance and permitting support</span>
                  </li>
                </ul>
              </a>
            </Link>

            <Link href="/services/wifi-installation">
              <a className="block border-2 border-gray-200 rounded-xl p-8 hover:border-primary-400 transition cursor-pointer" data-testid="service-wifi-installation">
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-3">
                  <Wifi className="text-primary-600" />
                  Wi-Fi Network Installation
                </h3>
                <p className="text-gray-600 mb-4">
                  Complete Wi-Fi network design, installation, and optimization for commercial properties,
                  multi-tenant buildings, and business facilities.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Professional site surveys</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Custom network design</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                    <span>Ongoing support and maintenance</span>
                  </li>
                </ul>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding relative overflow-hidden text-white">
        {/* Background Image with Blur */}
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: 'url(/hero-bg.jpg)',
            filter: 'blur(3px)',
            transform: 'scale(1.1)',
          }}
        />
        
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/40" />
        
        {/* Blue Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary-600/80 to-primary-800/80" />
        
        {/* Content */}
        <div className="container-custom text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Connectivity?
          </h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Contact us today for a free consultation and discover how SignaConnect can enhance
            your property with professional Wi-Fi solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <a className="btn bg-white text-primary-600 hover:bg-gray-100 shadow-lg">
                Get Started
              </a>
            </Link>
            <a href="tel:9085324503" className="btn btn-outline border-white text-white hover:bg-white/10 shadow-lg">
              Call (908) 532-4503
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
