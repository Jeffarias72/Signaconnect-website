import { Link } from 'wouter';
import { Wifi, CheckCircle, Shield, Clock, FileCheck, Zap } from 'lucide-react';
import { useEffect } from 'react';

export default function WifiInstallationPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-20">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo */}
            <div className="mb-6 flex justify-center">
              <img 
                src="/signaconnect-logo.png" 
                alt="SignaConnect Logo" 
                className="h-16 md:h-20 w-auto drop-shadow-lg"
              />
            </div>
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-2xl mb-6">
              <Wifi size={40} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Wi-Fi Network Installation</h1>
            <p className="text-xl text-primary-100 mb-8">
              Deploy enterprise-grade Wi-Fi that delivers seamless connectivity across your entire property with zero disruption to your operations
            </p>
            <Link href="/signup">
              <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
                Get Started Today
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Easy Setup Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Setup Made Simple</h2>
            <p className="text-xl text-gray-600">
              We handle everything from planning to deployment, making the process effortless for you
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Clock className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Minimal Disruption</h3>
              <p className="text-gray-600">
                Scheduled installations during off-hours or low-traffic periods to keep your business running smoothly
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shield className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fully Managed</h3>
              <p className="text-gray-600">
                Our team handles site surveys, equipment procurement, installation, and configuration—you don't lift a finger
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Zap className="text-primary-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fast Deployment</h3>
              <p className="text-gray-600">
                Most installations completed within 1-3 days depending on property size and complexity
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Legal Compliance Section */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-xl mb-4">
                <FileCheck className="text-green-600" size={32} />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">100% Legally Compliant</h2>
              <p className="text-xl text-gray-600">
                Every installation meets or exceeds all federal, state, and local regulations
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">FCC Certified Equipment</h3>
                <p className="text-gray-600">
                  All hardware meets Federal Communications Commission standards for wireless transmission
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Building Code Compliance</h3>
                <p className="text-gray-600">
                  Installations adhere to National Electrical Code (NEC) and local building requirements
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Safety Standards</h3>
                <p className="text-gray-600">
                  OSHA-compliant installation practices ensure worker and occupant safety throughout the process
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <CheckCircle className="text-green-500 mb-3" size={24} />
                <h3 className="text-lg font-semibold mb-2">Data Privacy Protection</h3>
                <p className="text-gray-600">
                  Network security configured to comply with GDPR, CCPA, and industry-specific data protection regulations
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Enterprise-Grade Features</h2>
            <p className="text-xl text-gray-600">
              Professional Wi-Fi solutions built for reliability, security, and performance
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Professional Site Survey</h3>
              <p className="text-gray-600">
                RF analysis to identify optimal access point placement for complete coverage
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Custom Network Design</h3>
              <p className="text-gray-600">
                Tailored architecture that matches your property layout and user density
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Enterprise Access Points</h3>
              <p className="text-gray-600">
                Commercial-grade hardware with advanced features like band steering and load balancing
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Secure Configuration</h3>
              <p className="text-gray-600">
                WPA3 encryption, VLAN segmentation, and guest network isolation
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">Seamless Roaming</h3>
              <p className="text-gray-600">
                802.11r fast roaming for uninterrupted connectivity as users move throughout your space
              </p>
            </div>
            
            <div className="border border-gray-200 p-6 rounded-xl hover:shadow-lg transition-shadow">
              <CheckCircle className="text-primary-600 mb-3" size={24} />
              <h3 className="text-lg font-semibold mb-2">24/7 Monitoring</h3>
              <p className="text-gray-600">
                Proactive network monitoring with automatic alerts and remote troubleshooting
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-primary-50">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Process</h2>
            <p className="text-xl text-gray-600">
              A proven approach that ensures successful deployment every time
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-sm flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                1
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Initial Consultation</h3>
                <p className="text-gray-600">
                  We discuss your connectivity needs, property layout, user requirements, and budget to create a tailored solution
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                2
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Site Survey & Design</h3>
                <p className="text-gray-600">
                  Our engineers conduct an on-site assessment and create a detailed network design with coverage maps and equipment specifications
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                3
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Professional Installation</h3>
                <p className="text-gray-600">
                  Certified technicians install all equipment, run cabling if needed, and configure the network according to best practices
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                4
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Testing & Optimization</h3>
                <p className="text-gray-600">
                  Comprehensive testing ensures coverage targets are met, followed by fine-tuning for optimal performance
                </p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                5
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Ongoing Support</h3>
                <p className="text-gray-600">
                  24/7 monitoring, regular maintenance, firmware updates, and dedicated support keep your network running smoothly
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-gradient-to-br from-primary-600 to-primary-800 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready for Reliable, High-Performance Wi-Fi?
          </h2>
          <p className="text-xl text-primary-100 mb-8 max-w-2xl mx-auto">
            Get a free consultation and customized network design proposal for your property
          </p>
          <Link href="/signup">
            <a className="btn bg-white text-primary-600 hover:bg-primary-50 text-lg px-8 py-3">
              Request Your Free Consultation
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
