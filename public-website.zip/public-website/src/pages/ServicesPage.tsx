import { Link } from 'wouter';
import { Wifi, Shield, Users, Zap, CheckCircle } from 'lucide-react';
import { useEffect } from 'react';

export default function ServicesPage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-16">
        <div className="container-custom text-center">
          {/* Logo */}
          <div className="mb-6 flex justify-center">
            <img 
              src="/signaconnect-logo.png" 
              alt="SignaConnect Logo" 
              className="h-16 md:h-20 w-auto drop-shadow-lg"
            />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h1>
          <p className="text-xl text-primary-100 max-w-2xl mx-auto">
            Comprehensive Wi-Fi and connectivity solutions for your business
          </p>
        </div>
      </section>

      {/* Services Detail */}
      <section className="section-padding">
        <div className="container-custom space-y-16">
          {/* Carrier Enhancement */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Shield className="text-primary-600" size={32} />
                </div>
                <h2 className="text-3xl font-bold">Carrier Enhancement</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                Eliminate dead zones and ensure reliable cellular connectivity throughout your entire property
                with our advanced carrier enhancement solutions.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Boost signal strength for all major carriers (Verizon, AT&T, T-Mobile)</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Improve indoor cellular coverage by up to 32x</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Support for voice, text, and 4G/5G data</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>FCC-certified equipment and professional installation</span>
                </li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-primary-50 to-primary-100 p-8 rounded-2xl">
              <h3 className="text-xl font-semibold mb-4">Ideal For:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Office buildings with poor reception</li>
                <li>• Multi-tenant residential properties</li>
                <li>• Warehouses and industrial facilities</li>
                <li>• Hotels and hospitality venues</li>
                <li>• Healthcare facilities</li>
              </ul>
              <Link href="/services/carrier-enhancement">
                <a className="btn bg-green-600 hover:bg-green-700 text-white mt-6 inline-block" data-testid="link-carrier-enhancement">
                  Learn More
                </a>
              </Link>
            </div>
          </div>

          {/* Data Collection */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Users className="text-primary-600" size={32} />
                </div>
                <h2 className="text-3xl font-bold">Data Collection Services</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                Gain valuable insights into network usage, performance metrics, and user behavior
                to make data-driven decisions about your connectivity infrastructure.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Real-time network performance monitoring</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Usage analytics and reporting dashboards</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Trend analysis and capacity planning</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Custom reporting for stakeholders</span>
                </li>
              </ul>
            </div>
            <div className="bg-gradient-to-br from-primary-50 to-primary-100 p-8 rounded-2xl">
              <h3 className="text-xl font-semibold mb-4">Key Benefits:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Optimize network resource allocation</li>
                <li>• Identify and resolve performance issues</li>
                <li>• Understand peak usage patterns</li>
                <li>• Plan for future expansion</li>
                <li>• ROI tracking and reporting</li>
              </ul>
              <Link href="/services/data-collection">
                <a className="btn bg-green-600 hover:bg-green-700 text-white mt-6 inline-block" data-testid="link-data-collection">
                  Learn More
                </a>
              </Link>
            </div>
          </div>

          {/* EV Installation */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 bg-gradient-to-br from-primary-50 to-primary-100 p-8 rounded-2xl">
              <h3 className="text-xl font-semibold mb-4">Our Partnership:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Partnered with EOS for expert installations</li>
                <li>• Level 2 chargers (240V, up to 80A)</li>
                <li>• DC fast charging options</li>
                <li>• Networked charging management</li>
                <li>• Revenue-sharing opportunities</li>
              </ul>
              <Link href="/services/ev-charging">
                <a className="btn bg-green-600 hover:bg-green-700 text-white mt-6 inline-block" data-testid="link-ev-charging">
                  Learn More
                </a>
              </Link>
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Zap className="text-primary-600" size={32} />
                </div>
                <h2 className="text-3xl font-bold">EV Charging Installation</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                Add value to your property and support the electric vehicle revolution with professional
                EV charging infrastructure installation through our partnership with EOS.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Complete electrical infrastructure assessment</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Permitting and compliance support</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Professional installation by certified electricians</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Ongoing maintenance and support</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Wi-Fi Network Installation */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 bg-gradient-to-br from-primary-50 to-primary-100 p-8 rounded-2xl">
              <h3 className="text-xl font-semibold mb-4">What We Provide:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• Professional site survey and analysis</li>
                <li>• Custom network architecture design</li>
                <li>• Enterprise-grade access points</li>
                <li>• Secure network configuration</li>
                <li>• Ongoing monitoring and support</li>
              </ul>
              <Link href="/services/wifi-installation">
                <a className="btn bg-green-600 hover:bg-green-700 text-white mt-6 inline-block" data-testid="link-wifi-installation">
                  Learn More
                </a>
              </Link>
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Wifi className="text-primary-600" size={32} />
                </div>
                <h2 className="text-3xl font-bold">Wi-Fi Network Installation</h2>
              </div>
              <p className="text-lg text-gray-600 mb-6">
                Deploy robust, high-performance Wi-Fi networks that deliver seamless connectivity
                across your entire property with optimal coverage and speed.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Complete end-to-end network deployment</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Coverage optimization for maximum performance</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Guest network separation and security</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="text-primary-500 mt-1 flex-shrink-0" size={20} />
                  <span>Scalable solutions that grow with your needs</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Request a consultation to discuss your specific needs and receive a customized solution.
          </p>
          <Link href="/signup">
            <a className="btn btn-primary text-lg">
              Request a Quote
            </a>
          </Link>
        </div>
      </section>
    </div>
  );
}
