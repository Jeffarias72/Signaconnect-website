# SignaConnect Public Website

Public-facing website for SignaConnect Wi-Fi Management services, built with React, TypeScript, and Tailwind CSS.

## Features

- **Landing Page**: Professional homepage showcasing services and company value proposition
- **Services Page**: Detailed information about carrier enhancement, Wi-Fi installation, data collection, and EV charging
- **Multi-Step Signup Wizard**: 
  - Company information capture
  - Contact details collection
  - Multiple location support with CSV upload
  - Review and submit functionality
- **Contract Portal**: Token-based access for viewing and signing contracts without login
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Form Validation**: React Hook Form with comprehensive validation

## Getting Started

### Prerequisites

- Node.js 18+ 
- CRM backend running (provides API endpoints)

### Installation

```bash
# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Update VITE_API_BASE_URL in .env to point to your CRM backend
```

### Development

```bash
npm run dev
```

The site will be available at `http://localhost:3000`

### Production Build

```bash
npm run build
```

The build output will be in the `dist` directory, ready for deployment.

## Environment Variables

- `VITE_API_BASE_URL`: URL of the CRM backend API (e.g., `https://crm.signaconnect.com`)

## API Integration

The website integrates with the CRM backend through two public endpoints:

1. **POST /api/public/signup**: Creates company, contact, deal, and jobs
2. **GET /api/public/contract/:token**: Retrieves contract details for signing

## CSV Upload Format

For bulk location upload, use CSV with these columns:

```csv
siteName,serviceType,address,addressLine2,city,state,zipCode,notes,desiredStartDate
Main Office,Carrier Enhancement,123 Main St,,Springfield,NJ,07081,Need installation by Q2,2025-03-15
Warehouse,Wi-Fi Network Installation,456 Industrial Blvd,,Newark,NJ,07102,,2025-04-01
```

Required columns: `siteName`, `address`, `city`, `state`, `zipCode`

## Deployment

### Replit Static Deployment (Recommended)

Replit Static Deployments are **free for Core subscribers** with 100 GiB/month data transfer included.

**Step-by-step deployment:**

1. **Create a new Repl**:
   - Go to Replit dashboard
   - Click "Create Repl" 
   - Choose "Import from GitHub" or upload the `public-website/` folder
   - Name it: `signaconnect-public-website`

2. **Set environment variable**:
   - Open the Secrets tool (🔒 icon)
   - Add secret:
     - Key: `VITE_API_BASE_URL`
     - Value: Your CRM backend URL (e.g., `https://your-crm.replit.app`)

3. **Build the website**:
   ```bash
   npm install
   npm run build
   ```

4. **Deploy**:
   - Click the "Deploy" button in Repl header
   - Select **"Static Deployment"**
   - Configure settings:
     - Build directory: `dist`
     - Build command: `npm run build` (auto-detects)
   - Click "Deploy"

5. **Custom domain** (Optional):
   - In deployment settings, click "Add custom domain"
   - Enter: `signaconnect.com` (or `www.signaconnect.com`)
   - Add the CNAME record to your DNS provider as instructed
   - Wait 5-60 minutes for DNS propagation

**Costs**: Free for Replit Core subscribers. Data transfer: first 100 GiB/month free, then $0.10/GiB.

### Other Deployment Options

- **Vercel**: Connect GitHub repo and deploy automatically
- **Netlify**: Drag and drop `dist` folder or connect repo  
- **AWS S3 + CloudFront**: Upload `dist` to S3 bucket with CloudFront CDN

Make sure to set `VITE_API_BASE_URL` environment variable in your deployment platform.

## Project Structure

```
public-website/
├── src/
│   ├── components/     # Header, Footer
│   ├── pages/          # Home, Services, Signup, Contract Portal
│   ├── lib/            # API client
│   ├── styles/         # Tailwind CSS
│   └── App.tsx         # Router configuration
├── public/             # Static assets
└── vite.config.ts      # Vite configuration
```

## Contact

For support, contact SignaConnect:
- Phone: (908) 532-4503
- Email: info@signaconnect.com
